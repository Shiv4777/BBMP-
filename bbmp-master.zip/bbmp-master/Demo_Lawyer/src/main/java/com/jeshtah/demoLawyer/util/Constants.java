package com.jeshtah.demoLawyer.util;

public class Constants {
	public final static String USER_EXITS="This User Aleready Exists...!";
	public final static String USER_NOT_EXITS="This User Not Exists...!";
	public final static String EMPTY="Please Fill the all flieds...!";
	public final static String SUCESS="User Registerd Sucessfully";
	public final static String SEND_RESET_URL="Reset Link Sent Registerd Email id...";
}
