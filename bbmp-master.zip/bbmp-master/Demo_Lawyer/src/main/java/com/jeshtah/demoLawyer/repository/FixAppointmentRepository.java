package com.jeshtah.demoLawyer.repository;

import org.springframework.data.repository.CrudRepository;

import com.jeshtah.demoLawyer.model.FixAppointment;

public interface FixAppointmentRepository extends CrudRepository<FixAppointment, Integer> {

}
