package com.jeshtah.demoLawyer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLawyerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoLawyerApplication.class, args);
	}

}
