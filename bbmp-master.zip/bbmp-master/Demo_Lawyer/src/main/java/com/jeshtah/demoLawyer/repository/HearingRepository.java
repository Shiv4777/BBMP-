package com.jeshtah.demoLawyer.repository;

import org.springframework.data.repository.CrudRepository;

import com.jeshtah.demoLawyer.model.Hearing;

public interface HearingRepository extends CrudRepository<Hearing, Integer> {

}
