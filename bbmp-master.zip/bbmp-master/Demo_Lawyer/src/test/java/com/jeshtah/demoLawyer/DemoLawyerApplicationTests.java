package com.jeshtah.demoLawyer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoLawyerApplicationTests {

	@Test
	void contextLoads() {
	}

}
